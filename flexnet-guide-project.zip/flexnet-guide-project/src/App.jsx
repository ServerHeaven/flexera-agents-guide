import { useState } from "react";

const sections = {
  overview: {
    title: "Visión General",
    icon: "📋",
  },
  windows: {
    title: "Windows",
    icon: "🪟",
  },
  linux: {
    title: "Linux",
    icon: "🐧",
  },
  mac: {
    title: "macOS",
    icon: "🍎",
  },
  containers: {
    title: "Contenedores",
    icon: "📦",
  },
  config: {
    title: "Configuración",
    icon: "⚙️",
  },
  troubleshooting: {
    title: "Solución de Problemas",
    icon: "🔧",
  },
};

function CodeBlock({ children, title }) {
  const [copied, setCopied] = useState(false);
  return (
    <div style={{ margin: "16px 0", borderRadius: 8, overflow: "hidden", border: "1px solid #2a2a3a" }}>
      {title && (
        <div style={{ background: "#1a1a2e", padding: "8px 16px", fontSize: 12, color: "#8892b0", fontFamily: "'JetBrains Mono', monospace", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span>{title}</span>
          <button
            onClick={() => { navigator.clipboard?.writeText(children); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
            style={{ background: "none", border: "1px solid #333", color: "#8892b0", padding: "2px 10px", borderRadius: 4, cursor: "pointer", fontSize: 11 }}
          >
            {copied ? "✓ Copiado" : "Copiar"}
          </button>
        </div>
      )}
      <pre style={{ background: "#0d1117", padding: 16, margin: 0, overflowX: "auto", fontSize: 13, lineHeight: 1.6, color: "#c9d1d9", fontFamily: "'JetBrains Mono', monospace" }}>
        <code>{children}</code>
      </pre>
    </div>
  );
}

function InfoBox({ type = "info", children }) {
  const styles = {
    info: { bg: "#0d2847", border: "#1a5fb4", icon: "ℹ️", label: "Información" },
    warning: { bg: "#3d2e00", border: "#c4a000", icon: "⚠️", label: "Advertencia" },
    danger: { bg: "#3d0000", border: "#c01c28", icon: "🚨", label: "Importante" },
    tip: { bg: "#0d3324", border: "#26a269", icon: "💡", label: "Consejo" },
  };
  const s = styles[type];
  return (
    <div style={{ margin: "16px 0", padding: "14px 18px", borderRadius: 8, background: s.bg, borderLeft: `4px solid ${s.border}`, fontSize: 14, lineHeight: 1.7, color: "#e0e0e0" }}>
      <strong style={{ color: s.border }}>{s.icon} {s.label}:</strong>{" "}
      {children}
    </div>
  );
}

function StepCard({ number, title, children }) {
  return (
    <div style={{ display: "flex", gap: 16, margin: "20px 0", padding: 0 }}>
      <div style={{ minWidth: 38, height: 38, borderRadius: "50%", background: "linear-gradient(135deg, #e85d04, #f48c06)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 16, color: "#fff", flexShrink: 0, marginTop: 2 }}>
        {number}
      </div>
      <div style={{ flex: 1 }}>
        <h4 style={{ margin: "0 0 8px 0", fontSize: 16, color: "#f0f0f0", fontWeight: 700 }}>{title}</h4>
        <div style={{ color: "#b0b8c8", lineHeight: 1.75, fontSize: 14 }}>{children}</div>
      </div>
    </div>
  );
}

function Badge({ children, color = "#e85d04" }) {
  return (
    <span style={{ display: "inline-block", background: color + "22", color, padding: "2px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase", border: `1px solid ${color}44` }}>
      {children}
    </span>
  );
}

function TableRow({ cells, header }) {
  const Tag = header ? "th" : "td";
  return (
    <tr>
      {cells.map((c, i) => (
        <Tag key={i} style={{ padding: "10px 14px", borderBottom: "1px solid #1e2a3a", textAlign: "left", fontSize: 13, color: header ? "#f48c06" : "#c0c8d8", fontWeight: header ? 700 : 400, background: header ? "#0d1117" : "transparent" }}>
          {c}
        </Tag>
      ))}
    </tr>
  );
}

// ──────── CONTENT SECTIONS ────────

function OverviewContent() {
  return (
    <div>
      <h2 style={{ color: "#f0f0f0", fontSize: 26, margin: "0 0 8px", fontWeight: 800 }}>¿Qué son los FlexNet Agents?</h2>
      <p style={{ color: "#8892b0", fontSize: 15, lineHeight: 1.8, margin: "0 0 20px" }}>
        Flexera ofrece distintos tipos de agentes según el producto y objetivo. Los dos principales son el <strong style={{ color: "#f48c06" }}>FlexNet Agent</strong> (para Engineering Applications) y el <strong style={{ color: "#f48c06" }}>FlexNet Inventory Agent</strong> (para IT Asset Management / FlexNet Manager Suite). Esta guía cubre ambos.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16, margin: "24px 0" }}>
        {[
          {
            title: "FlexNet Agent (Eng. Apps)",
            ver: "v5.17 (última)",
            desc: "Se instala en cada máquina con servidor de licencias FlexNet Publisher. Comunica datos de uso al servidor FlexNet Manager for Engineering Applications.",
            tags: ["Licencias concurrentes", "Uso de software", "lmgrd/lmstat"],
          },
          {
            title: "FlexNet Inventory Agent (FNMS)",
            ver: "v17.x+",
            desc: "Se despliega en dispositivos gestionados para recolectar inventario de hardware y software. Se comunica con Inventory Beacons que reportan al servidor central.",
            tags: ["Inventario SW/HW", "Discovery", "Compliance"],
          },
          {
            title: "Flexera Kubernetes Inv. Agent",
            ver: "2024+",
            desc: "Agente específico para recolectar inventario de clústeres Kubernetes: nodos, pods, imágenes de contenedor y software dentro de ellas.",
            tags: ["Kubernetes", "OCI", "Contenedores"],
          },
        ].map((card, i) => (
          <div key={i} style={{ background: "#111827", border: "1px solid #1e2a3a", borderRadius: 12, padding: 20, transition: "border-color 0.2s" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
              <h3 style={{ color: "#f0f0f0", fontSize: 16, margin: 0, fontWeight: 700 }}>{card.title}</h3>
              <Badge>{card.ver}</Badge>
            </div>
            <p style={{ color: "#8892b0", fontSize: 13, lineHeight: 1.7, margin: "0 0 14px" }}>{card.desc}</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {card.tags.map((t, j) => (
                <span key={j} style={{ fontSize: 11, padding: "3px 8px", borderRadius: 6, background: "#1a2332", color: "#6e8bb8", border: "1px solid #253347" }}>{t}</span>
              ))}
            </div>
          </div>
        ))}
      </div>

      <h3 style={{ color: "#f0f0f0", fontSize: 18, marginTop: 32 }}>Requisitos Generales Comunes</h3>
      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 12 }}>
          <thead>
            <TableRow header cells={["Requisito", "FlexNet Agent (Eng. Apps)", "FlexNet Inventory Agent"]} />
          </thead>
          <tbody>
            <TableRow cells={["Arquitectura", "64-bit obligatorio (Windows y Linux)", "64-bit recomendado"]} />
            <TableRow cells={["RAM mínima", "512 MB recomendado", "2 GB recomendado"]} />
            <TableRow cells={["Puertos por defecto", "Puerto del servidor FNMEA (ej. 443/8888)", "HTTP 80 (beacon upload/download)"]} />
            <TableRow cells={["Permisos", "Administrador local / root", "Administrador / root (servicios del sistema)"]} />
            <TableRow cells={["Conectividad", "Al servidor FlexNet Manager", "Al Inventory Beacon asignado"]} />
          </tbody>
        </table>
      </div>

      <InfoBox type="info">
        Todos los instaladores se descargan desde el <strong>Flexera Product and License Center</strong> (community.flexera.com → Download Products and Licenses). Necesitas credenciales activas de Flexera Community.
      </InfoBox>

      <h3 style={{ color: "#f0f0f0", fontSize: 18, marginTop: 32 }}>Arquitectura de Comunicación</h3>
      <div style={{ background: "#0d1117", borderRadius: 12, padding: 24, border: "1px solid #1e2a3a", margin: "12px 0", fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: "#c9d1d9", lineHeight: 2 }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ color: "#f48c06", fontWeight: 700 }}>┌─────────────────────────────────────────────┐</div>
          <div style={{ color: "#f48c06", fontWeight: 700 }}>│   FlexNet Manager (Servidor Central/Cloud)  │</div>
          <div style={{ color: "#f48c06", fontWeight: 700 }}>└──────────────────────┬──────────────────────┘</div>
          <div style={{ color: "#555" }}>                       │ HTTPS</div>
          <div style={{ color: "#555" }}>                       ▼</div>
          <div style={{ color: "#26a269", fontWeight: 700 }}>┌──────────────────────────────────────────────┐</div>
          <div style={{ color: "#26a269", fontWeight: 700 }}>│     Inventory Beacon (relay/intermediario)    │</div>
          <div style={{ color: "#26a269", fontWeight: 700 }}>└───────┬──────────────┬───────────────┬────────┘</div>
          <div style={{ display: "flex", justifyContent: "center", gap: 40, marginTop: 8 }}>
            <div>
              <div style={{ color: "#555" }}>│ HTTP/80</div>
              <div style={{ color: "#555" }}>▼</div>
              <div style={{ color: "#1a85ff" }}>[ Agent Win ]</div>
            </div>
            <div>
              <div style={{ color: "#555" }}>│ HTTP/80</div>
              <div style={{ color: "#555" }}>▼</div>
              <div style={{ color: "#1a85ff" }}>[ Agent Linux ]</div>
            </div>
            <div>
              <div style={{ color: "#555" }}>│ HTTP/80</div>
              <div style={{ color: "#555" }}>▼</div>
              <div style={{ color: "#1a85ff" }}>[ Agent Mac ]</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function WindowsContent() {
  const [subTab, setSubTab] = useState("eng");
  return (
    <div>
      <h2 style={{ color: "#f0f0f0", fontSize: 26, margin: "0 0 16px", fontWeight: 800 }}>Instalación en Windows</h2>

      <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>
        {[
          { id: "eng", label: "FlexNet Agent (Eng. Apps)" },
          { id: "inv", label: "FlexNet Inventory Agent" },
        ].map((t) => (
          <button key={t.id} onClick={() => setSubTab(t.id)} style={{ padding: "8px 18px", borderRadius: 8, border: subTab === t.id ? "1px solid #f48c06" : "1px solid #1e2a3a", background: subTab === t.id ? "#f48c0618" : "#111827", color: subTab === t.id ? "#f48c06" : "#8892b0", cursor: "pointer", fontSize: 13, fontWeight: 600, transition: "all 0.2s" }}>
            {t.label}
          </button>
        ))}
      </div>

      {subTab === "eng" ? (
        <>
          <InfoBox type="info">
            La versión más reciente del FlexNet Agent para Engineering Applications es la <strong>5.17</strong> (incluida en FNMEA 2025 R2). Requiere entorno de <strong>64 bits</strong> obligatorio.
          </InfoBox>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Plataformas soportadas</h3>
          <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
            Windows Server 2016, 2019, 2022 y Windows 10/11 (64-bit). Se requiere que Java no es necesario para el agente — usa su propio runtime InstallAnywhere.
          </p>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Instalación con Wizard (Interactiva)</h3>

          <StepCard number={1} title="Descargar el instalador">
            Accede al <strong>Flexera Product and License Center</strong>. Descarga el archivo <code style={{ color: "#f48c06" }}>FlexNet_Agent_5_7-All_Platforms.zip</code> (el nombre del ZIP es histórico, contiene la versión actual). Extrae el instalador de Windows (.exe) del ZIP.
          </StepCard>

          <StepCard number={2} title="Ejecutar el instalador">
            Haz doble clic en el archivo <code style={{ color: "#f48c06" }}>.exe</code> del agente. Se lanza el wizard de InstallAnywhere. Sigue las instrucciones en pantalla. Se te pedirá la URL del servidor FlexNet Manager y las credenciales.
          </StepCard>

          <StepCard number={3} title="Configurar conexión al servidor">
            Proporciona la URL del servidor FlexNet Manager for Engineering Applications (ej. <code style={{ color: "#f48c06" }}>https://fnmea-server.empresa.com</code>) y el puerto configurado. El agente registrará este equipo como servidor de licencias gestionado.
          </StepCard>

          <StepCard number={4} title="Verificar el servicio">
            Tras la instalación, el agente se registra como un servicio de Windows. Verifica en <code style={{ color: "#f48c06" }}>services.msc</code> que el servicio "FlexNet Agent" está en ejecución.
          </StepCard>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Instalación Silenciosa (Línea de Comandos)</h3>
          <InfoBox type="warning">
            Debes abrir el CMD o PowerShell como <strong>Administrador</strong>. Windows requiere privilegios elevados explícitos aunque el usuario sea administrador.
          </InfoBox>

          <CodeBlock title="Instalación silenciosa básica">
{`:: Ejecutar como Administrador
FlexNetAgent-5.17-windows-x64.exe -i silent

:: Con archivo de respuesta personalizado
FlexNetAgent-5.17-windows-x64.exe -i silent -f agent_response.properties`}
          </CodeBlock>

          <CodeBlock title="Ejemplo de archivo de respuesta (agent_response.properties)">
{`# Configuración del servidor
FLEXNET_MANAGER_URL=https://fnmea-server.empresa.com
FLEXNET_MANAGER_PORT=443
AGENT_INSTALL_DIR=C:\\Program Files\\FlexNet Agent
# Frecuencia de reporte (en minutos)
REPORT_INTERVAL=60`}
          </CodeBlock>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Gestión del Servicio</h3>
          <CodeBlock title="Comandos del servicio Windows">
{`:: Verificar estado
sc query "FlexNet Agent"

:: Detener el agente
net stop "FlexNet Agent"

:: Iniciar el agente
net start "FlexNet Agent"

:: Desinstalar desde línea de comandos
FlexNetAgent-5.17-windows-x64.exe -i silent -r`}
          </CodeBlock>
        </>
      ) : (
        <>
          <InfoBox type="info">
            El FlexNet Inventory Agent se despliega en dispositivos finales para recolectar inventario de software y hardware. Se comunica con un <strong>Inventory Beacon</strong> intermedio.
          </InfoBox>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Métodos de despliegue</h3>
          <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
            Existen dos métodos principales: <strong>Adopción automática</strong> (el beacon descubre y despliega automáticamente) o <strong>Despliegue con herramienta de terceros</strong> (SCCM, GPO, etc.) donde preparas el paquete manualmente.
          </p>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Despliegue manual / terceros en Windows</h3>

          <StepCard number={1} title="Obtener el paquete MSI">
            Desde la consola web de FlexNet Manager Suite, ve a <strong>Discovery &amp; Inventory → Settings → Inventory agent for download</strong>. Descarga el paquete de Windows (.msi).
          </StepCard>

          <StepCard number={2} title="Preparar el archivo de configuración bootstrap">
            Descarga el archivo de ejemplo <code style={{ color: "#f48c06" }}>mgssetup.ini</code> desde la misma página. Edita para incluir la URL de tu Inventory Beacon.
          </StepCard>

          <CodeBlock title="Ejemplo mgssetup.ini (bootstrap config)">
{`[ManageSoft]
; URL del Inventory Beacon asignado
MGSFT_BOOTSTRAP_DOWNLOAD=http://beacon-server.empresa.com/ManageSoftDL
MGSFT_BOOTSTRAP_UPLOAD=http://beacon-server.empresa.com/ManageSoftRL
; Ejecutar policy tras instalación (1=sí)
MGSFT_RUNPOLICY=1`}
          </CodeBlock>

          <StepCard number={3} title="Instalar vía línea de comandos">
            Usa msiexec para instalar silenciosamente:
          </StepCard>

          <CodeBlock title="Instalación silenciosa con MSI">
{`:: Instalación silenciosa básica
msiexec /i ManageSoft.msi /qn

:: Con log de instalación
msiexec /i ManageSoft.msi /qn /l*v C:\\temp\\flexnet_install.log

:: Especificando directorio de instalación
msiexec /i ManageSoft.msi /qn INSTALLDIR="C:\\Program Files (x86)\\ManageSoft"`}
          </CodeBlock>

          <StepCard number={4} title="Verificar la instalación">
            El agente se instala por defecto en <code style={{ color: "#f48c06" }}>%ProgramFiles(x86)%\ManageSoft</code>. Los logs se encuentran en <code style={{ color: "#f48c06" }}>%ProgramData%\ManageSoft\log</code>.
          </StepCard>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Archivos de log clave</h3>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 8 }}>
              <thead><TableRow header cells={["Archivo", "Componente"]} /></thead>
              <tbody>
                <TableRow cells={["installation.log", "Log del instalador (ndlaunch)"]} />
                <TableRow cells={["policy.log", "Descarga de políticas (mgspolicy)"]} />
                <TableRow cells={["schedule.log", "Programador de tareas (ndschedag)"]} />
                <TableRow cells={["tracker.log", "Inventario (ndtrack)"]} />
                <TableRow cells={["uploader.log", "Subida de archivos (ndupload)"]} />
                <TableRow cells={["usageagent.log", "Tracking de uso (mgsusageag)"]} />
              </tbody>
            </table>
          </div>

          <InfoBox type="tip">
            Para impedir que usuarios desinstalen el agente desde "Agregar o quitar programas", puedes configurar una preferencia en el archivo de configuración que oculta la entrada del panel de control.
          </InfoBox>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Desinstalación</h3>
          <CodeBlock title="Desinstalar el Inventory Agent">
{`:: Desinstalar silenciosamente
msiexec /x ManageSoft.msi /qn

:: O usando el Product Code del MSI
msiexec /x {PRODUCT-CODE-GUID} /qn`}
          </CodeBlock>
        </>
      )}
    </div>
  );
}

function LinuxContent() {
  const [subTab, setSubTab] = useState("eng");
  return (
    <div>
      <h2 style={{ color: "#f0f0f0", fontSize: 26, margin: "0 0 16px", fontWeight: 800 }}>Instalación en Linux</h2>

      <div style={{ display: "flex", gap: 8, marginBottom: 24, flexWrap: "wrap" }}>
        {[
          { id: "eng", label: "FlexNet Agent (Eng. Apps)" },
          { id: "inv", label: "FlexNet Inventory Agent" },
        ].map((t) => (
          <button key={t.id} onClick={() => setSubTab(t.id)} style={{ padding: "8px 18px", borderRadius: 8, border: subTab === t.id ? "1px solid #f48c06" : "1px solid #1e2a3a", background: subTab === t.id ? "#f48c0618" : "#111827", color: subTab === t.id ? "#f48c06" : "#8892b0", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
            {t.label}
          </button>
        ))}
      </div>

      {subTab === "eng" ? (
        <>
          <InfoBox type="info">
            En UNIX/Linux, el instalador de FlexNet Agent ejecuta <strong>silenciosamente por defecto</strong>. También puede usar un response file o lanzar el wizard de InstallAnywhere con la opción <code>-i gui</code> (requiere X11/display).
          </InfoBox>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Plataformas soportadas</h3>
          <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
            RHEL 7.x, 8.x, 9.x · CentOS 7.x, 8.x · SUSE Linux Enterprise 12, 15 · Ubuntu 18.04+, 20.04+, 22.04+ (64-bit). Desde 2025 R2 se soporta también <strong>Linux ARM64 (Aarch64)</strong> en RHEL.
          </p>

          <StepCard number={1} title="Descargar y extraer">
            Descarga <code style={{ color: "#f48c06" }}>FlexNet_Agent_5_7-All_Platforms.zip</code> desde Flexera Product Center. Extrae el instalador de Linux:
          </StepCard>

          <CodeBlock title="Extraer el instalador">
{`unzip FlexNet_Agent_5_7-All_Platforms.zip
# El archivo de Linux será algo como:
# FlexNetAgent-5.17-linux-x64.bin`}
          </CodeBlock>

          <StepCard number={2} title="Dar permisos de ejecución">
            <code style={{ color: "#f48c06" }}>chmod +x FlexNetAgent-5.17-linux-x64.bin</code>
          </StepCard>

          <StepCard number={3} title="Ejecutar la instalación (silenciosa por defecto)">
            Por defecto, la ejecución es silenciosa. Usa un response file para configurar sin interacción:
          </StepCard>

          <CodeBlock title="Instalación silenciosa con response file">
{`# Instalación silenciosa (por defecto en Linux)
sudo ./FlexNetAgent-5.17-linux-x64.bin -i silent

# Con response file personalizado
sudo ./FlexNetAgent-5.17-linux-x64.bin -i silent \\
  -f /ruta/a/agent_response.properties

# Para lanzar el wizard gráfico (requiere X11)
sudo ./FlexNetAgent-5.17-linux-x64.bin -i gui`}
          </CodeBlock>

          <StepCard number={4} title="Verificar el servicio">
            El agente se instala como servicio del sistema. Verifica que está corriendo:
          </StepCard>

          <CodeBlock title="Verificar el agente">
{`# Verificar servicio
systemctl status flexnetagent

# O en sistemas más antiguos
service flexnetagent status

# Ver logs
tail -f /var/log/flexnetagent/*.log`}
          </CodeBlock>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>ARM64 (Aarch64) - Nuevo en 2025 R2</h3>
          <InfoBox type="tip">
            Desde la versión 2025 R2, el FlexNet Agent soporta Linux ARM64 para entornos como AWS Graviton. La funcionalidad es equivalente a la versión x86_64. El proceso de instalación es idéntico usando el instalador específico para ARM64.
          </InfoBox>
        </>
      ) : (
        <>
          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 8 }}>Despliegue del Inventory Agent en Linux</h3>
          <InfoBox type="warning">
            La instalación requiere <strong>privilegios de root</strong>. El agente instala dos servicios del sistema: <code>ndschedag</code> (programador) y <code>mgsusageag</code> (tracking de uso).
          </InfoBox>

          <StepCard number={1} title="Preparar el archivo bootstrap (mgsft_rollout_response)">
            Este archivo <strong>DEBE estar en su lugar antes de ejecutar el instalador</strong>. Debe ubicarse en <code style={{ color: "#f48c06" }}>/var/tmp/mgsft_rollout_response</code>.
          </StepCard>

          <CodeBlock title="Contenido de /var/tmp/mgsft_rollout_response">
{`MGSFT_BOOTSTRAP_DOWNLOAD=http://beacon.empresa.com/ManageSoftDL
MGSFT_BOOTSTRAP_UPLOAD=http://beacon.empresa.com/ManageSoftRL
MGSFT_RUNPOLICY=1`}
          </CodeBlock>

          <StepCard number={2} title="Instalar según la distribución">
            FlexNet Inventory Agent usa el sistema de paquetes nativo de cada distribución:
          </StepCard>

          <CodeBlock title="RPM (RHEL, CentOS, Oracle, SUSE, Fedora)">
{`# Asegurarse de que el response file está en su sitio
cat /var/tmp/mgsft_rollout_response

# Instalar el paquete RPM
sudo rpm -ivh managesoft-[VERSION].x86_64.rpm`}
          </CodeBlock>

          <CodeBlock title="DEB (Debian, Ubuntu)">
{`# Asegurarse de que el response file está en su sitio
cat /var/tmp/mgsft_rollout_response

# Instalar el paquete DEB
sudo dpkg -i managesoft_[VERSION]_amd64.deb`}
          </CodeBlock>

          <StepCard number={3} title="Verificar instalación y servicios">
            Tras la instalación, los binarios quedan en <code style={{ color: "#f48c06" }}>/opt/managesoft/bin</code> y los datos de trabajo en <code style={{ color: "#f48c06" }}>/var/opt/managesoft</code>.
          </StepCard>

          <CodeBlock title="Verificar servicios y logs">
{`# Verificar servicios
systemctl status ndschedag
systemctl status mgsusageag

# En AIX, ambos servicios están en el grupo "managesoft"
startsrc -g managesoft   # Iniciar
stopsrc -g managesoft    # Detener

# Logs del agente
ls /var/opt/managesoft/log/
# Archivos: installation.log, policy.log, tracker.log, 
#           schedule.log, uploader.log, usageagent.log`}
          </CodeBlock>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Configuración post-instalación</h3>
          <CodeBlock title="Aplicar configuración con mgsconfig">
{`# Crear archivo temporal de configuración
cat > /var/tmp/tempconfig.ini << 'EOF'
[ManageSoft\\Usage Agent\\CurrentVersion]
Disabled=False
StartupDelay=600
Lowprofile=True

[ManageSoft\\Tracker\\CurrentVersion]
Lowprofile=True
EOF

# Aplicar configuración
/opt/managesoft/bin/mgsconfig -i /var/tmp/tempconfig.ini`}
          </CodeBlock>

          <InfoBox type="tip">
            El enfoque de <code>/opt/managesoft/bin/mgsconfig</code> es el método estándar para aplicar configuración del agente en todas las plataformas UNIX/macOS/Linux, según la documentación oficial de Flexera.
          </InfoBox>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Certificados HTTPS</h3>
          <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
            En Linux (a diferencia de Windows), la configuración de certificados CA para HTTPS con el beacon requiere <strong>configuración manual</strong>. Coloca el certificado CA en la ubicación esperada y configúralo en las preferencias del agente si usas HTTPS en vez de HTTP para la comunicación con el beacon.
          </p>
        </>
      )}
    </div>
  );
}

function MacContent() {
  return (
    <div>
      <h2 style={{ color: "#f0f0f0", fontSize: 26, margin: "0 0 16px", fontWeight: 800 }}>Instalación en macOS</h2>

      <InfoBox type="warning">
        <strong>GateKeeper:</strong> El paquete de instalación del agente de inventario para macOS <strong>puede no estar firmado</strong> (depende de la versión). Si no lo está, deberás desactivar GateKeeper temporalmente antes de instalar, y reactivarlo después. Desde macOS Catalina 10.15, solo se soportan agentes de <strong>64 bits</strong> (versiones 2019 R2+).
      </InfoBox>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 24 }}>FlexNet Inventory Agent en macOS</h3>
      <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
        macOS se trata como una plataforma de tipo UNIX. El proceso es muy similar a Linux: se necesita el archivo de response bootstrap y luego se instala el paquete .PKG.
      </p>

      <StepCard number={1} title="Preparar el archivo bootstrap">
        <strong>Ambos archivos deben estar en <code style={{ color: "#f48c06" }}>/var/tmp/</code> antes de ejecutar el instalador:</strong> el archivo <code>mgsft_rollout_response</code> y el paquete .PKG.
      </StepCard>

      <CodeBlock title="Crear /var/tmp/mgsft_rollout_response">
{`MGSFT_BOOTSTRAP_DOWNLOAD=http://beacon.empresa.com/ManageSoftDL
MGSFT_BOOTSTRAP_UPLOAD=http://beacon.empresa.com/ManageSoftRL
MGSFT_RUNPOLICY=1`}
      </CodeBlock>

      <StepCard number={2} title="(Opcional) Desactivar GateKeeper si el paquete no está firmado">
        Solo si el paquete no está firmado por Apple:
      </StepCard>

      <CodeBlock title="Gestionar GateKeeper">
{`# Desactivar GateKeeper temporalmente
sudo spctl --master-disable

# Verificar estado
spctl --status
# Debería mostrar: assessments disabled

# DESPUÉS de instalar, reactivar
sudo spctl --master-enable`}
      </CodeBlock>

      <StepCard number={3} title="Instalar el paquete .PKG">
        La instalación debe ejecutarse con sudo desde Terminal:
      </StepCard>

      <CodeBlock title="Instalar vía Terminal">
{`# Asegurarse de que el response file está en /var/tmp/
ls /var/tmp/mgsft_rollout_response

# Instalar el paquete
sudo installer -pkg /var/tmp/ManageSoft-[VERSION].pkg -target /`}
      </CodeBlock>

      <StepCard number={4} title="Verificar la instalación">
        Los binarios se instalan en <code style={{ color: "#f48c06" }}>/opt/managesoft/bin</code> y los logs en <code style={{ color: "#f48c06" }}>/var/opt/managesoft/log</code>.
      </StepCard>

      <CodeBlock title="Verificación post-instalación">
{`# Verificar que los binarios existen
ls /opt/managesoft/bin/

# Comprobar logs
ls /var/opt/managesoft/log/

# Verificar que el agente puede comunicarse con el beacon
cat /var/opt/managesoft/log/policy.log`}
      </CodeBlock>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Configuración post-instalación</h3>
      <CodeBlock title="Aplicar configuración con mgsconfig (igual que Linux)">
{`# Crear configuración
cat > /var/tmp/tempconfig.ini << 'EOF'
[ManageSoft\\Usage Agent\\CurrentVersion]
Disabled=False
StartupDelay=600
Lowprofile=True
EOF

# Aplicar
/opt/managesoft/bin/mgsconfig -i /var/tmp/tempconfig.ini`}
      </CodeBlock>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Despliegue con JAMF</h3>
      <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
        Para desplegar con JAMF u otra herramienta MDM, el proceso es similar a cualquier otro paquete .PKG. Lo crítico es asegurarse de que <code style={{ color: "#f48c06" }}>mgsft_rollout_response</code> se despliega en <code style={{ color: "#f48c06" }}>/var/tmp/</code> <strong>antes</strong> de que se ejecute la instalación del paquete. Configura tu herramienta de despliegue para:
      </p>
      <div style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7, paddingLeft: 20, margin: "8px 0" }}>
        1. Primero entregar el archivo <code style={{ color: "#f48c06" }}>mgsft_rollout_response</code> a <code>/var/tmp/</code><br />
        2. Luego ejecutar la instalación del .PKG<br />
        3. Opcionalmente ejecutar un script post-instalación con <code>mgsconfig</code>
      </div>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Problema conocido: Java y macOS</h3>
      <InfoBox type="warning">
        En macOS, puede aparecer un popup de Java obsoleto durante el escaneo de inventario si existe una instalación vieja de Java en <code>/System/Library/Frameworks/JavaVM.framework</code>. Para solucionarlo, excluye ese directorio del file scanning desde la UI web de FlexNet Manager (Inventory Settings) o pasa el parámetro <code>-o excludedirectory="/System/Library/Frameworks/JavaVM.framework"</code> al agente de inventario.
      </InfoBox>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Certificados HTTPS en macOS</h3>
      <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
        Al igual que en Linux, si usas HTTPS para la comunicación con el beacon, necesitarás configurar manualmente los certificados CA. Windows gestiona esto automáticamente, pero en macOS/UNIX se requiere configuración explícita.
      </p>
    </div>
  );
}

function ContainersContent() {
  const [subTab, setSubTab] = useState("k8s");
  return (
    <div>
      <h2 style={{ color: "#f0f0f0", fontSize: 26, margin: "0 0 16px", fontWeight: 800 }}>Contenedores (Docker &amp; Kubernetes)</h2>

      <div style={{ display: "flex", gap: 8, marginBottom: 24, flexWrap: "wrap" }}>
        {[
          { id: "k8s", label: "Kubernetes Agent" },
          { id: "docker", label: "Docker / Podman" },
        ].map((t) => (
          <button key={t.id} onClick={() => setSubTab(t.id)} style={{ padding: "8px 18px", borderRadius: 8, border: subTab === t.id ? "1px solid #f48c06" : "1px solid #1e2a3a", background: subTab === t.id ? "#f48c0618" : "#111827", color: subTab === t.id ? "#f48c06" : "#8892b0", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
            {t.label}
          </button>
        ))}
      </div>

      {subTab === "k8s" ? (
        <>
          <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7, margin: "0 0 20px" }}>
            Flexera ofrece <strong>dos agentes</strong> específicos para Kubernetes, independientes del FlexNet Inventory Agent tradicional:
          </p>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16, margin: "16px 0" }}>
            <div style={{ background: "#111827", border: "1px solid #1e2a3a", borderRadius: 12, padding: 20 }}>
              <h4 style={{ color: "#f48c06", margin: "0 0 8px" }}>Flexera Kubernetes Inventory Agent</h4>
              <p style={{ color: "#8892b0", fontSize: 13, lineHeight: 1.7, margin: 0 }}>
                Agente completo. Recomendado para la mayoría de entornos. Recoge recursos del clúster vía API de Kubernetes, inventario de software de imágenes de contenedor, datos del IBM License Service (opcional) y metadatos de instancias cloud.
              </p>
              <Badge color="#26a269">Recomendado</Badge>
            </div>
            <div style={{ background: "#111827", border: "1px solid #1e2a3a", borderRadius: 12, padding: 20 }}>
              <h4 style={{ color: "#f48c06", margin: "0 0 8px" }}>Lightweight Kubernetes Agent</h4>
              <p style={{ color: "#8892b0", fontSize: 13, lineHeight: 1.7, margin: 0 }}>
                Para entornos de alta seguridad. Menor huella, más control manual. Recoge información del clúster pero inspecciona imágenes con un proceso más seguro. Trata su contenedor como inmutable por defecto.
              </p>
              <Badge color="#1a85ff">Alta seguridad</Badge>
            </div>
          </div>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Arquitecturas soportadas</h3>
          <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
            <strong>x86_64</strong> (AMD/Intel), <strong>ARM64/Aarch64</strong> (AWS Graviton), <strong>s390x</strong> (IBM System z/zSystems). Solo se soporta <strong>un agente Kubernetes por clúster</strong>.
          </p>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Instalación del Flexera Kubernetes Inventory Agent</h3>

          <StepCard number={1} title="Descargar el archivo desde FlexNet Manager">
            En la consola web, ve a <strong>Data Collection → IT Assets Inventory Tasks → Inventory Settings → Inventory agent for download</strong> y descarga el archivo del Flexera Kubernetes Inventory Agent (.tar.gz).
          </StepCard>

          <StepCard number={2} title="Cargar la imagen en tu registro OCI">
            El agente se despliega como una aplicación nativa de Kubernetes. Necesitas subir la imagen a tu registro de contenedores (OCI container registry).
          </StepCard>

          <CodeBlock title="Cargar imagen en el registro">
{`# Extraer el archivo descargado
tar xzf flexera-kubernetes-agent-[VERSION].tar.gz

# La estructura extraída contiene:
# - Archivos YAML base
# - generate.sh (script interactivo de configuración)
# - install.sh (script de instalación)
# - Directorios por arquitectura (x86_64, aarch64, s390x)

# Cargar la imagen en tu registro OCI
docker load -i images/flexera-kia-[VERSION]-x86_64.tar
docker tag flexera-kia:[VERSION] tu-registro.empresa.com/flexera-kia:[VERSION]
docker push tu-registro.empresa.com/flexera-kia:[VERSION]`}
          </CodeBlock>

          <StepCard number={3} title="Generar el YAML de configuración">
            Ejecuta el script interactivo <code style={{ color: "#f48c06" }}>generate.sh</code> que te guía para crear el archivo YAML personalizado. Los dos valores <strong>obligatorios</strong> son la URL del beacon y la URL del registro de imágenes.
          </StepCard>

          <CodeBlock title="Generar configuración YAML">
{`# Ejecutar script interactivo
./generate.sh

# El script preguntará por:
# - URL del Inventory Beacon (OBLIGATORIO)
# - URL del registro OCI de la imagen (OBLIGATORIO)
# - Arquitectura (x86_64/aarch64/s390x)
# - Configuraciones avanzadas (opcional)

# Genera un archivo YAML personalizado para tu clúster`}
          </CodeBlock>

          <StepCard number={4} title="Instalar en el clúster Kubernetes">
            Usa el script de instalación con el YAML generado:
          </StepCard>

          <CodeBlock title="Instalar en Kubernetes">
{`# Instalar el operador y el agente
./install.sh

# El agente:
# 1. Se conecta al Kubernetes API
# 2. Suscribe a event streams de recursos
# 3. Recolecta inventario de nodos, pods, namespaces
# 4. Inspecciona imágenes de contenedor para software
# 5. Sube archivos .ndi al Inventory Beacon`}
          </CodeBlock>

          <InfoBox type="danger">
            Solo <strong>una instancia</strong> del Flexera Kubernetes Inventory Agent está soportada por clúster. Si ya tienes uno activo, debes fusionar la configuración en lugar de crear un nuevo despliegue.
          </InfoBox>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Archivos de inventario generados</h3>
          <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
            Ambos agentes Kubernetes producen archivos <code style={{ color: "#f48c06" }}>.ndi</code> que se suben al Inventory Beacon. Contienen inventario de nodos, pods y namespaces del clúster. El agente completo genera además archivos adicionales con inventario de software de las imágenes de contenedor.
          </p>
        </>
      ) : (
        <>
          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 8 }}>Inventario Docker y Podman</h3>
          <InfoBox type="info">
            Desde la versión <strong>15.0.0</strong> (2020 R1), el FlexNet Inventory Agent incluye un <strong>Docker tracker</strong>. Esta funcionalidad <strong>NO está habilitada por defecto</strong> y debe activarse explícitamente. Soporte para <strong>Podman</strong> se añadió posteriormente.
          </InfoBox>

          <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
            Para Docker/Podman, <strong>no</strong> se instala un agente separado dentro del contenedor. El FlexNet Inventory Agent debe estar instalado en el <strong>host</strong> donde corren los contenedores. Funciona así:
          </p>

          <div style={{ background: "#0d1117", borderRadius: 12, padding: 20, border: "1px solid #1e2a3a", margin: "16px 0", fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: "#c9d1d9", lineHeight: 1.8 }}>
            <div style={{ color: "#f48c06", fontWeight: 700 }}>Flujo de inventario "Zero Footprint":</div>
            <div style={{ marginTop: 8 }}>
              1. El Docker tracker del agente monitorea el Docker Engine<br />
              2. Detecta cuando un contenedor se inicia desde una imagen<br />
              3. Carga el componente de inventario (ndtrack) DENTRO del contenedor en ejecución<br />
              4. Ejecuta el inventario dentro del contenedor<br />
              5. Reporta el inventario al host<br />
              6. Remueve ndtrack del contenedor (zero footprint)<br />
              7. Solo necesita hacerlo una vez por imagen
            </div>
          </div>

          <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Activar inventario Docker</h3>

          <StepCard number={1} title="Habilitar desde la UI web de FlexNet Manager">
            Ve a <strong>Discovery &amp; Inventory → Settings</strong>. En la sección <strong>"Container scanning"</strong>, activa la casilla:
          </StepCard>

          <div style={{ background: "#111827", border: "1px solid #1e2a3a", borderRadius: 12, padding: 20, margin: "16px 0" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
              <div style={{ width: 18, height: 18, border: "2px solid #f48c06", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <span style={{ color: "#f48c06", fontSize: 14, fontWeight: 700 }}>✓</span>
              </div>
              <span style={{ color: "#e0e0e0", fontSize: 14 }}>Enable Docker inventory and running inventory agent inside Docker containers</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 18, height: 18, border: "2px solid #f48c06", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <span style={{ color: "#f48c06", fontSize: 14, fontWeight: 700 }}>✓</span>
              </div>
              <span style={{ color: "#e0e0e0", fontSize: 14 }}>Enable Podman inventory and running inventory agent inside Podman containers</span>
            </div>
          </div>

          <StepCard number={2} title="Esperar propagación de política">
            Una vez habilitado, la configuración se propaga a través de los beacons a los agentes instalados en los hosts. Este proceso puede tomar <strong>24-48 horas</strong> hasta que se complete la recogida de inventario, la subida y la reconciliación.
          </StepCard>

          <StepCard number={3} title="Verificar resultados">
            En la UI web de FlexNet Manager, ve a <strong>Discovery &amp; Inventory → Containers → All Containers</strong>. Ahí verás el inventario de hosts Docker, imágenes de contenedor y contenedores activos con el software detectado.
          </StepCard>

          <InfoBox type="tip">
            Como cada imagen Docker es inmutable, el agente solo necesita inventariar una vez por imagen. El usage agent (mgsusageag) se encarga de trackear cuándo los contenedores se inician, detienen y destruyen.
          </InfoBox>
        </>
      )}
    </div>
  );
}

function ConfigContent() {
  return (
    <div>
      <h2 style={{ color: "#f0f0f0", fontSize: 26, margin: "0 0 16px", fontWeight: 800 }}>Configuración Avanzada</h2>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 16 }}>Puertos y Comunicación</h3>
      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 8 }}>
          <thead><TableRow header cells={["Puerto", "Protocolo", "Uso"]} /></thead>
          <tbody>
            <TableRow cells={["80", "HTTP", "Comunicación por defecto entre agente e Inventory Beacon (upload/download)"]} />
            <TableRow cells={["443", "HTTPS", "Comunicación segura con beacon o servidor central"]} />
            <TableRow cells={["27000-27009", "TCP", "Rango por defecto de FlexNet Publisher (lmgrd)"]} />
            <TableRow cells={["Configurable", "TCP", "Puerto del vendor daemon de FlexNet Publisher"]} />
          </tbody>
        </table>
      </div>

      <InfoBox type="info">
        Todos los puertos del FlexNet Inventory Agent son configurables vía preferencias. Puedes incluir el número de puerto en las URLs de configuración del beacon.
      </InfoBox>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Archivo config.ini (UNIX/macOS)</h3>
      <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
        El archivo <code style={{ color: "#f48c06" }}>config.ini</code> es el archivo principal de configuración del agente en plataformas UNIX. Se encuentra en <code style={{ color: "#f48c06" }}>/var/opt/managesoft/etc/config.ini</code>. Contiene los valores importados del bootstrap más los valores por defecto de fábrica.
      </p>

      <CodeBlock title="Ejemplo de secciones en config.ini">
{`[ManageSoft\\Launcher\\CurrentVersion]
NetworkSense=True

[ManageSoft\\NetSelector\\CurrentVersion]
SelectorAlgorithm=MgsSubnetMatch(,true)

[ManageSoft\\Usage Agent\\CurrentVersion]
Disabled=False
StartupDelay=600
Lowprofile=True

[ManageSoft\\Tracker\\CurrentVersion]
Lowprofile=True`}
      </CodeBlock>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Actualización parcial de config.ini</h3>
      <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
        No edites config.ini directamente. Usa <code style={{ color: "#f48c06" }}>mgsconfig</code> con un archivo "patch" que contenga solo los cambios:
      </p>

      <CodeBlock title="Actualizar configuración selectivamente">
{`# Crear un archivo con solo los cambios deseados
cat > /var/tmp/patch_config.ini << 'EOF'
[ManageSoft\\Launcher\\CurrentVersion]
NetworkSense=False
EOF

# Aplicar los cambios
/opt/managesoft/bin/mgsconfig -i /var/tmp/patch_config.ini

# Limpiar
rm /var/tmp/patch_config.ini`}
      </CodeBlock>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Configuración en Windows (Registro)</h3>
      <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
        En Windows, la configuración del agente se almacena en el Registro de Windows. Los valores del bootstrap se importan durante la instalación. Las preferencias se pueden configurar a través de:
      </p>
      <div style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7, paddingLeft: 20, margin: "8px 0" }}>
        • Parámetros de línea de comandos del MSI durante la instalación<br />
        • Transforms (.mst) aplicadas al MSI<br />
        • El archivo de configuración bootstrap (mgssetup.ini)<br />
        • Políticas de dispositivo descargadas desde el beacon
      </div>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Auto-actualización del Agente</h3>
      <InfoBox type="info">
        Desde la consola web de FlexNet Manager, en <strong>Inventory Settings → Inventory agent for automatic deployment → Version to deploy</strong>, puedes especificar la versión objetivo del agente. Los agentes controlados por política se actualizarán (o degradarán) automáticamente. 
      </InfoBox>
      <InfoBox type="warning">
        <strong>Limitación en UNIX con "least privilege":</strong> Los agentes instalados en modo de mínimos privilegios en plataformas UNIX <strong>no pueden auto-actualizarse</strong>. En esos casos, debes actualizar manualmente, usar una herramienta de terceros, o reinstalar vía adopción.
      </InfoBox>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Proteger personalizaciones</h3>
      <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
        Las políticas de dispositivo descargadas desde el beacon pueden sobrescribir tu configuración local. Consulta la sección "Protecting Your Customizations" en la documentación oficial de Flexera para impedir que las actualizaciones de política sobreescriban tus ajustes personalizados.
      </p>
    </div>
  );
}

function TroubleshootingContent() {
  return (
    <div>
      <h2 style={{ color: "#f0f0f0", fontSize: 26, margin: "0 0 16px", fontWeight: 800 }}>Solución de Problemas</h2>

      {[
        {
          q: "El agente no se comunica con el Inventory Beacon",
          a: "Verifica conectividad de red al beacon (telnet/curl al puerto 80 o 443). Comprueba que las URLs en mgsft_rollout_response (UNIX) o mgssetup.ini (Windows) son correctas. Revisa los logs en policy.log y uploader.log. Verifica que no hay un firewall/proxy bloqueando la comunicación.",
        },
        {
          q: "La instalación silenciosa en Windows no funciona",
          a: "Asegúrate de ejecutar como Administrador real (cmd elevado). Verifica la sintaxis del comando: para msiexec, no dejar espacios extra después de /v\". Revisa el log de instalación con /l*v para diagnóstico.",
        },
        {
          q: "En macOS aparece un popup de Java durante el escaneo",
          a: "Es un problema conocido con versiones antiguas de Java en /System/Library/Frameworks/JavaVM.framework. Solución: excluir ese directorio del file scanning desde Inventory Settings en la UI web, o pasar -o excludedirectory al agente.",
        },
        {
          q: "Los servicios del agente no inician en Linux",
          a: "Verifica que el response file estaba en /var/tmp/mgsft_rollout_response ANTES de la instalación. Revisa /var/opt/managesoft/log/installation.log. Asegúrate de que la instalación se hizo con sudo/root.",
        },
        {
          q: "El inventario de contenedores Docker no aparece",
          a: "Verifica que la opción \"Enable Docker inventory\" está habilitada en Inventory Settings → Container scanning. Espera 24-48 horas para que la política se propague y el inventario se procese. El agente debe estar instalado en el HOST, no dentro del contenedor.",
        },
        {
          q: "El Kubernetes Agent no reporta inventario",
          a: "Verifica que el pod del agente está corriendo (kubectl get pods). Comprueba que la URL del beacon en el YAML es correcta. Revisa los logs del pod. Asegúrate de que solo hay una instancia del agente por clúster.",
        },
        {
          q: "Problemas con certificados HTTPS en UNIX/macOS",
          a: "A diferencia de Windows, las plataformas UNIX requieren configuración manual de certificados CA. Coloca el certificado en la ubicación adecuada y configúralo en las preferencias del agente. Si no puedes resolver HTTPS, usa HTTP para bootstrap y cambia a HTTPS después.",
        },
      ].map((item, i) => (
        <details key={i} style={{ margin: "8px 0", border: "1px solid #1e2a3a", borderRadius: 8, overflow: "hidden" }}>
          <summary style={{ padding: "14px 18px", cursor: "pointer", background: "#111827", color: "#e0e0e0", fontWeight: 600, fontSize: 14, listStyle: "none", display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ color: "#f48c06" }}>▸</span> {item.q}
          </summary>
          <div style={{ padding: "14px 18px", background: "#0d1117", color: "#8892b0", fontSize: 14, lineHeight: 1.7, borderTop: "1px solid #1e2a3a" }}>
            {item.a}
          </div>
        </details>
      ))}

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 32 }}>Ubicaciones de logs por plataforma</h3>
      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 8 }}>
          <thead><TableRow header cells={["Plataforma", "Ubicación de logs"]} /></thead>
          <tbody>
            <TableRow cells={["Windows", "%ProgramData%\\ManageSoft\\log\\"]} />
            <TableRow cells={["Linux / macOS", "/var/opt/managesoft/log/"]} />
            <TableRow cells={["Linux (zero-touch, root)", "/var/tmp/flexera/log/"]} />
            <TableRow cells={["Kubernetes Agent", "kubectl logs <pod-name>"]} />
          </tbody>
        </table>
      </div>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Estado del Agente (UI Web)</h3>
      <p style={{ color: "#8892b0", fontSize: 14, lineHeight: 1.7 }}>
        Puedes monitorear versiones y estado de todos los agentes desplegados desde la consola web: <strong>Discovery &amp; Inventory → FlexNet Inventory Agent Status</strong>. Esta página muestra la versión instalada, última comunicación, y estado de cada dispositivo gestionado.
      </p>

      <h3 style={{ color: "#e0e0e0", fontSize: 18, marginTop: 28 }}>Enlaces a Documentación Oficial</h3>
      <div style={{ color: "#8892b0", fontSize: 14, lineHeight: 2 }}>
        • <strong>docs.flexera.com</strong> — Documentación oficial de todos los productos Flexera<br />
        • <strong>community.flexera.com</strong> — Foros y Knowledge Base de la comunidad Flexera<br />
        • FlexNet Agent Installation Guide (Eng. Apps) — Disponible en docs.flexera.com/fnmea/<br />
        • FlexNet Inventory Agent &amp; Managed Devices — PDF disponible en la documentación de FNMS
      </div>

      <InfoBox type="danger">
        Esta guía está basada en la documentación pública de Flexera disponible hasta la fecha. Las versiones, parámetros y comportamientos pueden cambiar entre releases. <strong>Siempre consulta la documentación oficial de Flexera correspondiente a tu versión específica</strong> antes de realizar cualquier instalación en producción.
      </InfoBox>
    </div>
  );
}

// ──────── MAIN APP ────────

export default function FlexNetGuide() {
  const [active, setActive] = useState("overview");
  const [menuOpen, setMenuOpen] = useState(false);

  const content = {
    overview: <OverviewContent />,
    windows: <WindowsContent />,
    linux: <LinuxContent />,
    mac: <MacContent />,
    containers: <ContainersContent />,
    config: <ConfigContent />,
    troubleshooting: <TroubleshootingContent />,
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0e1a", color: "#e0e0e0", fontFamily: "'Segoe UI', -apple-system, sans-serif" }}>
      {/* ── HEADER ── */}
      <div style={{ background: "linear-gradient(135deg, #0d1117 0%, #1a1428 50%, #0d1117 100%)", borderBottom: "1px solid #1e2a3a", padding: "24px 0" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 24px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
            <div style={{ width: 48, height: 48, borderRadius: 12, background: "linear-gradient(135deg, #e85d04, #f48c06)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>
              🛡️
            </div>
            <div>
              <h1 style={{ margin: 0, fontSize: 24, fontWeight: 800, color: "#f0f0f0", letterSpacing: -0.5 }}>
                FlexNet Agents <span style={{ color: "#f48c06" }}>— Guía de Instalación y Configuración</span>
              </h1>
              <p style={{ margin: "4px 0 0", fontSize: 13, color: "#6e7b91" }}>
                Flexera · FlexNet Agent (Eng. Apps) · FlexNet Inventory Agent (FNMS) · Kubernetes Agent
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ── MOBILE MENU TOGGLE ── */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 24px" }}>
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          style={{ display: "none", width: "100%", padding: "12px", margin: "12px 0 0", background: "#111827", border: "1px solid #1e2a3a", borderRadius: 8, color: "#e0e0e0", fontSize: 14, cursor: "pointer", textAlign: "left" }}
          className="mobile-menu-toggle"
        >
          {sections[active].icon} {sections[active].title} ▾
        </button>
      </div>

      {/* ── LAYOUT ── */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "24px", display: "flex", gap: 24, alignItems: "flex-start" }}>
        {/* Sidebar */}
        <nav style={{ minWidth: 210, position: "sticky", top: 24, flexShrink: 0 }}>
          <div style={{ background: "#111827", border: "1px solid #1e2a3a", borderRadius: 12, padding: 8, overflow: "hidden" }}>
            {Object.entries(sections).map(([key, sec]) => (
              <button
                key={key}
                onClick={() => { setActive(key); setMenuOpen(false); }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  width: "100%",
                  padding: "11px 14px",
                  border: "none",
                  borderRadius: 8,
                  background: active === key ? "#f48c0618" : "transparent",
                  color: active === key ? "#f48c06" : "#8892b0",
                  cursor: "pointer",
                  fontSize: 14,
                  fontWeight: active === key ? 700 : 500,
                  textAlign: "left",
                  transition: "all 0.15s",
                  borderLeft: active === key ? "3px solid #f48c06" : "3px solid transparent",
                }}
              >
                <span style={{ fontSize: 18 }}>{sec.icon}</span>
                {sec.title}
              </button>
            ))}
          </div>

          <div style={{ marginTop: 16, padding: 14, background: "#111827", border: "1px solid #1e2a3a", borderRadius: 12, fontSize: 11, color: "#555c70", lineHeight: 1.6 }}>
            <strong style={{ color: "#6e7b91" }}>Fuentes:</strong><br />
            docs.flexera.com<br />
            community.flexera.com<br />
            Documentación FNMEA 2025 R1/R2<br />
            FNMS 2025 R1 docs
          </div>
        </nav>

        {/* Main content */}
        <main style={{ flex: 1, minWidth: 0, background: "#111827", border: "1px solid #1e2a3a", borderRadius: 12, padding: "28px 32px" }}>
          {content[active]}
        </main>
      </div>

      {/* Footer */}
      <div style={{ borderTop: "1px solid #1e2a3a", padding: "20px 24px", textAlign: "center", fontSize: 12, color: "#3d4555", marginTop: 40 }}>
        Guía basada en documentación pública de Flexera (docs.flexera.com). No es documentación oficial de Flexera. Consulta siempre la documentación de tu versión específica antes de instalar en producción.
      </div>
    </div>
  );
}
